# Arena.ai Direct API — Reverse Engineered (2026-05-01)

## Key Endpoint

```
POST https://arena.ai/nextjs-api/stream/create-evaluation
Content-Type: text/plain;charset=UTF-8
```

This is a **streaming** endpoint (SSE/EventStream). The response contains image URLs as they're generated.

## Request Body Structure

```json
{
  "id": "<session-uuid>",           // e.g. "019de0c5-7fae-7eaf-b4ba-6395732122d9"
  "mode": "direct-battle",
  "modelAId": "<model-uuid>",        // see model IDs below
  "userMessageId": "<uuid>",
  "modelAMessageId": "<uuid>",
  "userMessage": {
    "content": "<prompt text>",
    "experimental_attachments": [],
    "metadata": {}
  },
  "modality": "image",
  "recaptchaV3Token": "<token>"      // May be required; see pitfalls
}
```

## Known Model IDs

| Model | ID |
|---|---|
| gpt-image-2 | `019db344-75b0-7acd-aa20-bcc095ca0ed9` |
| gemini-3.1-flash-image-preview | (from UI, not captured) |

## Authentication

Uses **Supabase Auth** cookies:
- `arena-auth-prod-v1.0` — base64-encoded JSON with `access_token` (JWT), `refresh_token`, user info
- `arena-auth-prod-v1.1` — complementary auth data
- `__cf_bm`, `cf_clearance` — Cloudflare tokens

The JWT in `arena-auth-prod-v1.0` is a Supabase JWT with:
- `iss`: `https://hogzoeqzcrdvkwtvodi.supabase.co/auth/v1`
- `sub`: user UUID
- `exp`: expiration timestamp

## Cookie Extraction from Browser

When the full cookie string is needed (e.g. for API calls from a different environment):

```javascript
// In browser console on arena.ai:
copy(document.cookie)
```

If the clipboard truncates, extract in chunks:
```javascript
var c = document.cookie;
console.log('Length:', c.length);
console.log('PART1:', c.substring(0, 2000));
console.log('PART2:', c.substring(2000, 4000));
console.log('PART3:', c.substring(4000));
```

## Pitfalls

1. **recaptchaV3Token** — The cURL from the browser contains a long recaptcha token. Empty string may cause "User not found" or 403. The token is tied to the browser session and expires.

2. **Cookie expiration** — The `arena-auth-prod-v1.0` cookie expires (typically 1 hour). The `refresh_token` can be used with Supabase's `/auth/v1/token?grant_type=refresh_token` endpoint, but the Supabase URL may not be reachable from all environments (DNS resolution issues in WSL2).

3. **Streaming response parsing** — The response is SSE format. Each line is either `data: {...}` or raw JSON. Parse each line as JSON and look for `imageUrl`, `image_url`, or `url` fields.

4. **WSL2 networking** — From WSL2, `127.0.0.1` on Windows is accessible on Windows 11 (mirrored networking). On older setups, use the Windows host IP from `/etc/resolv.conf`.

## n8n Integration Pattern

Since the `Execute Command` node is not available in all n8n installations, use the **bridge server pattern**:

1. Run a Flask/HTTP server on Windows that wraps the Arena API call
2. n8n calls it via `HTTP Request` node: `POST http://127.0.0.1:18765/generate`
3. The bridge server handles cookies, streaming, and image download
4. Returns `{"status": "ok", "image_path": "..."}` to n8n

See `scripts/arena_bridge_server.py` and `scripts/arena_api.py` for reference implementations.

---

## 2026-05-01 Session Updates

### New Pitfalls

5. **v1.0 Cookie Base64 Decoding Failure** — The raw `arena-auth-prod-v1.0` cookie (after stripping the `base64-` prefix) is 3173 characters long, which is 1 modulo 4. Standard base64 decoding fails with "Invalid base64-encoded string: number of data characters (3173) cannot be 1 more than a multiple of 4". Adding padding (`=`) does not resolve the issue. The decoded JSON (if successful) contains the `access_token` JWT needed for API calls.

6. **Raw v1.0 Cookie as Bearer Token** — Passing the entire v1.0 cookie value as the `Bearer` token in the `Authorization` header returns 401 `{"message":"User not found"}`. The API expects the JWT from the `access_token` field of the decoded v1.0 JSON, not the raw base64 string.

7. **v1.1 Cookie Not a Valid JWT** — The `arena-auth-prod-v1.1` cookie is not a JWT and cannot be used as a Bearer token. Using it results in 401 errors.

### Token Extraction Scripts

The following scripts were created to automate token extraction and updating, but currently do not resolve the base64 decoding issue:

- `extract_and_save_token.py` — Launches Playwright persistent Chrome profile, extracts cookies after user login
- `decode_and_update.py` — Attempts to decode v1.0 cookie and update `arena_api.py` with the JWT
- `test_cookie_api.py` — Tests API calls with various token formats
- `test_v10_bearer.py` — Tests v1.0 cookie as Bearer token

### Current Status

Token extraction from the browser profile works, but base64 decoding of the v1.0 cookie fails. The n8n workflow "Arena Image Generator" (ID: N8zlEb9Tff2yCulg) is non-functional until a valid JWT can be extracted and injected into the API client.

---

## 2026-05-01 Session 2 Updates (Late Night)

### Direct REST Endpoints Blocked

All tested direct REST API endpoints return **403 "Route not allowed"**:

| Endpoint | Status |
|---|---|
| `POST /api/v1/images/generations` | 403 |
| `POST /api/images/generate` | 403 |
| `POST /api/v1/image/generate` | 403 |
| `POST /api/generate` | 403 |

**Conclusion**: Arena.ai's public-facing REST API is blocked. The only known working endpoint is the NextJS-internal streaming endpoint `/nextjs-api/stream/create-evaluation`.

### Authentication Confirmed Working

The `arena-auth-prod-v1` cookie is confirmed as the canonical auth mechanism:

```
arena-auth-prod-v1=base64-<base64encoded JSON>
```

The base64-decoded JSON contains:
```json
{
  "access_token": "eyJ...",
  "token_type": "earer",
  "expires_in": 3600,
  "expires_at": 1777671218,
  "refresh_token": "6z2f2biqvyk6",
  "user": { ... Supabase user profile ... }
}
```

The `access_token` is a **Supabase JWT** (ES256 algorithm) with:
- `iss`: `https://<project>.supabase.co/auth/v1`
- `sub`: user UUID
- `exp`: ~1h from issuance
- `aud`: `"authenticated"`

**Confirmed**: The extracted JWT can be decoded and validated (confirmed 2026-05-01 at 20:08 UTC, token valid for ~45min remaining).

### NextJS Internal Endpoint

The actual image generation endpoint is:

```
POST https://arena.ai/nextjs-api/stream/create-evaluation
Content-Type: text/plain;charset=UTF-8
```

The request body is a streaming JSON payload. Auth may work via:
1. **Cookie-based**: Send `Cookie: arena-auth-prod-v1=<value>` header (full cookie value)
2. **Bearer**: Extract JWT `access_token` and send `Authorization: Bearer <jwt>`

Neither approach has been fully verified yet. The browser sends the request with session cookies (no Authorization header visible in Network tab — the NextJS handler reads cookies server-side).

### Model ID

From the cookie token investigation and previous sessions:
- `gpt-image-2` model ID: `019db344-75b0-7acd-aa20-bcc095ca0ed9`

### How to Capture the Real API Call

The `/nextjs-api/stream/create-evaluation` request is a POST that appears in the Network tab during image generation. To capture it:

1. F12 → Network → Clear
2. Generate an image
3. Find the POST request to `/nextjs-api/stream/create-evaluation`
4. Right-click → Copy → Copy as cURL

The cURL will contain the full request body, headers, and cookies needed to replicate the call.

### Recommended Approach Going Forward

Since public REST API is blocked and the NextJS endpoint requires session cookies:

1. **Browser automation (preferred)**: Continue using Playwright with persistent Chrome profile. It works reliably.
2. **Cookie-based API**: Extract `arena-auth-prod-v1` cookie from browser NextJS requests, send as Cookie header to `/nextjs-api/stream/create-evaluation`. This avoids Playwright but requires fresh cookies every ~1h.
3. **Hybrid**: Use Playwright to extract a fresh cookie, then use it for API calls until expiry.
