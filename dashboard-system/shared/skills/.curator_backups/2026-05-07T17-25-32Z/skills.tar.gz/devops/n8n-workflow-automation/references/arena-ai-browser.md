# Arena.ai Browser Automation Reference

## Key Learnings from 2026-05-01 Session

### Why Browser Over API
- Arena.ai API (`/nextjs-api/stream/create-evaluation`) requires JWT from `access_token` field in `arena-auth-prod-v1.0` cookie
- Base64 decoding of v1.0 cookie fails: length 3173 (1 mod 4), padding doesn't fix
- API returns `{"message":"User not found"}` even with extracted JWTs
- Browser automation with persistent profile is more reliable

### Browser Automation Setup

**Files:**
- `arena_generate.py` — Playwright script (Windows-side)
- `arena_bridge_server_wsl.py` — Flask bridge server (WSL2-side, port 18765)
- Both in `C:\Users\Damia\.openclaw\scripts\`

**Persistent Profile:**
- Location: `C:\Users\Damia\.openclaw\browser_profile\`
- Keeps arena.ai login cookies between runs
- Must use Playwright's `launch_persistent_context()`, not regular `launch()`

### Headless Mode Gotcha
- Added `--headless` flag support to `arena_generate.py`
- Arena.ai may detect headless and block/timeout
- Test headless before relying on it for n8n automation
- If headless fails, remove flag and run visible (works but needs Windows session)

### Bridge Server Pattern (WSL2 → Windows)
```python
# arena_bridge_server_wsl.py runs on WSL2
# Calls Windows script via:
cmd = f'cmd.exe /c "python {GENERATE_SCRIPT} --headless {escaped_prompt}"'
```

**Endpoint:** `POST http://<windows-ip>:18765/generate`
- Body: `{"prompt": "..."}`
- Returns JSON: `{"status": "ok", "image_path": "C:\\...", ...}`

**Windows IP for WSL2:** Get from `/etc/resolv.conf` (`nameserver` line), e.g., `172.20.192.1`

### arena_generate.py Key Selectors
- Prompt input: `textarea[placeholder*="prompt" i]`, `textarea`, `[contenteditable="true"]`
- Generate button: `button:has-text("Generate")`, `button[type="submit"]`
- Image detection: `img[src*="openai"]`, `img[src*="oaidalleapiprodscus"]`, `img[src*="blob:"]`
- Download: `button:has-text("Download")`, `a[download]`

### n8n Workflow Structure (Browser Automation)
1. **Schedule Trigger** — Daily at 20:00
2. **Code Node** — Generate prompt (4 styles × 7 motives × 7 quotes)
3. **HTTP Request** — `POST http://172.20.192.1:18765/generate` (bridge server)
4. **Code Node** — Parse JSON response
5. **IF Node** — Check `status == "ok"`
6. **Telegram Node** (success) — Send image file
7. **Telegram Node** (error) — Send error message

### Debugging Tips
- Check bridge server log: `/tmp/bridge.log`
- arena_generate.py prints to stdout/stderr (captured by bridge)
- Use `await page.screenshot()` on timeout/error
- Verify cookies in profile: Playwright script to list cookies
- Test bridge manually: `curl -X POST http://127.0.0.1:18765/generate -H "Content-Type: application/json" -d "{\"prompt\":\"test\"}"`

### Current Status (2026-05-01)
- ✅ Bridge server runs on WSL2 (port 18765)
- ✅ arena_generate.py supports `--headless`
- ✅ n8n workflow v4 imported (ID: N8zlEb9Tff2yCulg)
- ⚠️ Headless mode untested (timeout in test)
- ⚠️ API token approach abandoned (401 errors)
- ⚠️ Need to verify workflow activation + daily run
