---
name: n8n-api-control
title: n8n API Control
description: Steuerung von n8n über REST API - Workflow erstellen und ausführen ohne grafisches Interface
tags: [n8n, api, automation, devops]
version: 1.0
---

# n8n API Control Skill

Dieser Skill ermöglicht die Steuerung von n8n über die REST API anstelle von Mausklicks im Interface.

## Konfiguration

```python
import requests
import json

N8N_BASE_URL = "http://localhost:5678/api/v1"  # Standard-URL für lokales n8n
N8N_API_KEY = "HIER_N8N_API_KEY_EINFÜGEN"       # API Key aus n8n Settings

HEADERS = {
    "X-N8N-API-KEY": N8N_API_KEY,
    "Content-Type": "application/json",
    "Accept": "application/json"
}
```

## Funktionen

### create_workflow(name: str, nodes: list, connections: dict)

Erstellt einen neuen n8n-Workflow direkt über die API.

**Parameter:**
- `name`: Name des Workflows
- `nodes`: Liste von n8n-Nodes (Dictionaries)
- `connections`: Dictionary der Verbindungen

**Rückgabe:** JSON-Response mit Workflow-Daten oder None bei Fehler

```python
def create_workflow(name: str, nodes: list, connections: dict):
    payload = {
        "name": name,
        "nodes": nodes,
        "connections": connections,
        "active": False
    }
    
    try:
        response = requests.post(f"{N8N_BASE_URL}/workflows", headers=HEADERS, json=payload)
        response.raise_for_status()
        print(f"Erfolg! Workflow '{name}' wurde erstellt. ID: {response.json().get('id')}")
        return response.json()
    except Exception as e:
        print(f"Fehler beim Erstellen des Workflows: {e}")
        return None
```

### execute_workflow(workflow_id: str)

Startet einen Workflow in n8n anhand seiner ID.

**Parameter:**
- `workflow_id`: Die ID des zu startenden Workflows

**Rückgabe:** JSON-Response mit Ausführungsstatus oder None bei Fehler

```python
def execute_workflow(workflow_id: str):
    try:
        response = requests.post(
            f"{N8N_BASE_URL}/workflows/{workflow_id}/execute",
            headers=HEADERS
        )
        response.raise_for_status()
        print(f"Workflow erfolgreich ausgeführt!")
        return response.json()
    except Exception as e:
        print(f"Fehler bei der Ausführung: {e}")
        return None
```

## Ablauf für Phase 1

1. Bei Workflow-Erstellung: Nutze `create_workflow()` mit generiertem JSON für Nodes
2. Bei Workflow-Test: Nutze `execute_workflow()` mit der Workflow-ID
3. Immer mit API Key konfigurieren bevor Funktionen aufgerufen werden